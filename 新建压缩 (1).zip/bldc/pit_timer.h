


#include "common.h"

void pit_timer_init(void);
void led_init(void);
