
#include "zf_tim.h"
#include "zf_gpio.h"
#include "bldc_config.h"
#include "pwm.h"
#include "pwm_input.h"
#include "motor.h"
#include "battery.h"
#include "pit_timer.h"

#define LED_PIN P44

uint32 stime;

//-------------------------------------------------------------------------------------------------------------------
//  @brief      LED�ƹ����
//  @param      void                        
//  @return     void          
//  @since      v1.0
//  Sample usage:
//-------------------------------------------------------------------------------------------------------------------
void led_control(void)
{
    // LED״̬��ʾ
    if(battery_low_voltage)
    {
        // ��ص�ѹ���ͣ�LED���� ����
        if(0 == (stime%100))
        {
            LED_PIN = 0;
        }
        else if(10 == (stime%100))
        {
            LED_PIN = 1;
        }
    }
    else if(motor.restart_delay)
    {
        // ���ڶ�ת����ֹͣ LED����
        if(0 == (stime%5))
        {
            LED_PIN = !LED_PIN;
        }
    }
    else if(0 == motor.run_flag)
    {
        // ֹͣ LED����
        if(0 == (stime%100))
        {
            LED_PIN = !LED_PIN;
        }
    }
    else if(1 == motor.run_flag)
    {
        // �������� LED������
        if(0 == (stime%50))
        {
            LED_PIN = !LED_PIN;
        }
    }
    else if(2 == motor.run_flag)
    {
        // ���������ά��һ��ʱ�� �Ͽ���˸
        if(0 == (stime%10))
        {
            LED_PIN = !LED_PIN;
        }
    }
    else if(3 == motor.run_flag)
    {
        // �������� LED����
        LED_PIN = 0;
    }
}

//-------------------------------------------------------------------------------------------------------------------
//  @brief      ��ʱ��1�ж�
//  @param      void                        
//  @return     void          
//  @since      v1.0
//  Sample usage:
//-------------------------------------------------------------------------------------------------------------------
void TM1_Isr() interrupt 3
{
    stime++;
    
    battery_voltage_get();
    
    led_control();
    
    if(motor.restart_delay)
    {
        // ��ʱ����ʱ�����
        motor.restart_delay--;
    }
    else
    {
        if(0 == battery_low_voltage)
        {
            if(motor.duty && (0 == motor.run_flag))
            {
                motor_start();
            }
            else if((0 == motor.duty) && (3 == motor.run_flag))
            {
                motor_stop();
            }
        }
        else
        {
            // ��������ֹͣ����
            motor_stop();
        }
    }
}

//-------------------------------------------------------------------------------------------------------------------
//  @brief      ���ڶ�ʱ����ʼ��
//  @param      void                        
//  @return     void          
//  @since      v1.0
//  Sample usage:
//-------------------------------------------------------------------------------------------------------------------
void pit_timer_init(void)
{
    stime = 0;
    pit_timer_ms(TIM_1, 10);
}

//-------------------------------------------------------------------------------------------------------------------
//  @brief      LED��ʼ��
//  @param      void                        
//  @return     void          
//  @since      v1.0
//  Sample usage:
//-------------------------------------------------------------------------------------------------------------------
void led_init(void)
{
    gpio_mode(P4_4, GPO_PP);
    LED_PIN = 0;
}