#include "motor.h"
#include "math.h"


void motor_init(void)
{
	pwm_init(MOTORL_PWM1, 17000, 0);
	pwm_init(MOTORL_PWM2, 17000, 0);
	pwm_init(MOTORR_PWM1, 17000, 0);
	pwm_init(MOTORR_PWM2, 17000, 0);

    ctimer_count_init(ENCODER_L_A);	//��ʼ����ʱ��0��Ϊ�ⲿ����
	ctimer_count_init(ENCODER_R_A);	//��ʼ����ʱ��3��Ϊ�ⲿ����
//    gpio_pull_set(ENCODER_L_B,PULLUP);
//	gpio_pull_set(ENCODER_R_B,PULLUP);
    //pit_ms_init(PIT_CH0, 5);
}

void get_encoder(int16* speed_l, int16* speed_r)
{
	*speed_l = (int16)ctimer_count_read(ENCODER_L_A);
	*speed_r = (int16)ctimer_count_read(ENCODER_R_A);

	//����������
	ctimer_count_clean(ENCODER_L_A);
	ctimer_count_clean(ENCODER_R_A);

	//�ɼ�������Ϣ
	if(0 == ENCODER_L_B)    
	{
		*speed_l = -*speed_l;
	}
	if(1 == ENCODER_R_B)    
	{
		*speed_r = -*speed_r;
	}
}


void motor_control(int32 duty_l, int32 duty_r)
{
    //��ռ�ձ��޷�
	duty_l = (int)limit((float)duty_l, 10000);
	duty_r = (int)limit((float)duty_r, 10000);
    
    if(duty_l >= 0)											// �����ת
    {
        pwm_duty(MOTORL_PWM1, duty_l); 
        pwm_duty(MOTORL_PWM2, 0);                  
            
    }
    else													// ��෴ת
    {
        pwm_duty(MOTORL_PWM1, 0); 
        pwm_duty(MOTORL_PWM2, -duty_l);             
    }
    
    if(duty_r >= 0)											// �Ҳ���ת
    {
        pwm_duty(MOTORR_PWM1, duty_r); 
        pwm_duty(MOTORR_PWM2, 0);                  
    }
    else													// �Ҳ෴ת
    {
        pwm_duty(MOTORR_PWM1, 0); 
        pwm_duty(MOTORR_PWM2, -duty_r);             
    }
}
